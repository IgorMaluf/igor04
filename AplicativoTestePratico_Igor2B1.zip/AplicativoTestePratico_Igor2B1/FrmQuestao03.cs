﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicativoTestePratico_Igor2B1
{
    public partial class FrmQuestao03 : Form
    {
        public FrmQuestao03()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float preco1 = float.Parse(txtPreco1.Text);
            float preco2 = float.Parse(txtPreco2.Text);
            float preco3 = float.Parse(txtPreco3.Text);
            float ValorCompra;
            ValorCompra = preco1 + preco2 + preco3;
            lblResultado1.Text = (ValorCompra / 1).ToString("C");
            lblResultado2.Text = (ValorCompra / 2).ToString("C");
            lblResultado3.Text = (ValorCompra / 3).ToString("C");
            lblResultado4.Text = (ValorCompra / 4).ToString("C");
            lblResultado5.Text = (ValorCompra / 5).ToString("C");
        }
    }
}
