﻿namespace AplicativoTestePratico_Igor2B1
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao02));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtCamisaP = new System.Windows.Forms.TextBox();
            this.lblCamisaP = new System.Windows.Forms.Label();
            this.lblCamisaM = new System.Windows.Forms.Label();
            this.lblCamisaG = new System.Windows.Forms.Label();
            this.txtCamisaM = new System.Windows.Forms.TextBox();
            this.txtCamisaG = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblValorPagar = new System.Windows.Forms.Label();
            this.lblRS = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblQuest02 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtCamisaP
            // 
            this.txtCamisaP.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaP.Location = new System.Drawing.Point(30, 211);
            this.txtCamisaP.Name = "txtCamisaP";
            this.txtCamisaP.Size = new System.Drawing.Size(212, 43);
            this.txtCamisaP.TabIndex = 2;
            // 
            // lblCamisaP
            // 
            this.lblCamisaP.AutoSize = true;
            this.lblCamisaP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(122)))), ((int)(((byte)(95)))));
            this.lblCamisaP.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaP.Location = new System.Drawing.Point(24, 165);
            this.lblCamisaP.Name = "lblCamisaP";
            this.lblCamisaP.Size = new System.Drawing.Size(131, 31);
            this.lblCamisaP.TabIndex = 3;
            this.lblCamisaP.Text = "Camisa P";
            // 
            // lblCamisaM
            // 
            this.lblCamisaM.AutoSize = true;
            this.lblCamisaM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(122)))), ((int)(((byte)(95)))));
            this.lblCamisaM.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaM.Location = new System.Drawing.Point(24, 257);
            this.lblCamisaM.Name = "lblCamisaM";
            this.lblCamisaM.Size = new System.Drawing.Size(135, 31);
            this.lblCamisaM.TabIndex = 4;
            this.lblCamisaM.Text = "Camisa M";
            // 
            // lblCamisaG
            // 
            this.lblCamisaG.AutoSize = true;
            this.lblCamisaG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(122)))), ((int)(((byte)(95)))));
            this.lblCamisaG.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCamisaG.Location = new System.Drawing.Point(25, 337);
            this.lblCamisaG.Name = "lblCamisaG";
            this.lblCamisaG.Size = new System.Drawing.Size(134, 31);
            this.lblCamisaG.TabIndex = 5;
            this.lblCamisaG.Text = "Camisa G";
            // 
            // txtCamisaM
            // 
            this.txtCamisaM.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaM.Location = new System.Drawing.Point(31, 291);
            this.txtCamisaM.Name = "txtCamisaM";
            this.txtCamisaM.Size = new System.Drawing.Size(212, 43);
            this.txtCamisaM.TabIndex = 6;
            // 
            // txtCamisaG
            // 
            this.txtCamisaG.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCamisaG.Location = new System.Drawing.Point(30, 371);
            this.txtCamisaG.Name = "txtCamisaG";
            this.txtCamisaG.Size = new System.Drawing.Size(212, 43);
            this.txtCamisaG.TabIndex = 7;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(405, 43);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(314, 53);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblValorPagar
            // 
            this.lblValorPagar.AutoSize = true;
            this.lblValorPagar.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValorPagar.Location = new System.Drawing.Point(452, 165);
            this.lblValorPagar.Name = "lblValorPagar";
            this.lblValorPagar.Size = new System.Drawing.Size(206, 36);
            this.lblValorPagar.TabIndex = 9;
            this.lblValorPagar.Text = "Valor a pagar:";
            // 
            // lblRS
            // 
            this.lblRS.AutoSize = true;
            this.lblRS.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRS.Location = new System.Drawing.Point(398, 257);
            this.lblRS.Name = "lblRS";
            this.lblRS.Size = new System.Drawing.Size(55, 39);
            this.lblRS.TabIndex = 10;
            this.lblRS.Text = "R$";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(122)))), ((int)(((byte)(95)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.txtCamisaG);
            this.panel1.Controls.Add(this.lblCamisaG);
            this.panel1.Controls.Add(this.txtCamisaM);
            this.panel1.Controls.Add(this.lblCamisaP);
            this.panel1.Controls.Add(this.lblCamisaM);
            this.panel1.Controls.Add(this.txtCamisaP);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(373, 438);
            this.panel1.TabIndex = 11;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(204)))), ((int)(((byte)(143)))));
            this.panel2.Controls.Add(this.lblQuest02);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(373, 142);
            this.panel2.TabIndex = 8;
            // 
            // lblQuest02
            // 
            this.lblQuest02.AutoSize = true;
            this.lblQuest02.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest02.Location = new System.Drawing.Point(64, 50);
            this.lblQuest02.Name = "lblQuest02";
            this.lblQuest02.Size = new System.Drawing.Size(190, 36);
            this.lblQuest02.TabIndex = 12;
            this.lblQuest02.Text = "QUESTÃO 02";
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblRS);
            this.Controls.Add(this.lblValorPagar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao02";
            this.Text = "FrmQuestao02";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtCamisaP;
        private System.Windows.Forms.Label lblCamisaP;
        private System.Windows.Forms.Label lblCamisaM;
        private System.Windows.Forms.Label lblCamisaG;
        private System.Windows.Forms.TextBox txtCamisaM;
        private System.Windows.Forms.TextBox txtCamisaG;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblValorPagar;
        private System.Windows.Forms.Label lblRS;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblQuest02;
    }
}