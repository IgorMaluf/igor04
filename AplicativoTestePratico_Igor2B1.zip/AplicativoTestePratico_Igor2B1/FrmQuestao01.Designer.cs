﻿namespace AplicativoTestePratico_Igor2B1
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.lblQtdPaes = new System.Windows.Forms.Label();
            this.lblQtdBroas = new System.Windows.Forms.Label();
            this.txtBroas = new System.Windows.Forms.TextBox();
            this.txtPaes = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblQuest1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.lblValoraPagar = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQtdPaes
            // 
            this.lblQtdPaes.AutoSize = true;
            this.lblQtdPaes.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdPaes.Location = new System.Drawing.Point(3, 6);
            this.lblQtdPaes.Name = "lblQtdPaes";
            this.lblQtdPaes.Size = new System.Drawing.Size(275, 35);
            this.lblQtdPaes.TabIndex = 0;
            this.lblQtdPaes.Text = "Quantidade de Pães";
            // 
            // lblQtdBroas
            // 
            this.lblQtdBroas.AutoSize = true;
            this.lblQtdBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdBroas.Location = new System.Drawing.Point(3, 85);
            this.lblQtdBroas.Name = "lblQtdBroas";
            this.lblQtdBroas.Size = new System.Drawing.Size(269, 31);
            this.lblQtdBroas.TabIndex = 1;
            this.lblQtdBroas.Text = "Quantidade de Broas";
            // 
            // txtBroas
            // 
            this.txtBroas.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBroas.Location = new System.Drawing.Point(9, 119);
            this.txtBroas.Name = "txtBroas";
            this.txtBroas.Size = new System.Drawing.Size(269, 38);
            this.txtBroas.TabIndex = 2;
            // 
            // txtPaes
            // 
            this.txtPaes.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaes.Location = new System.Drawing.Point(9, 44);
            this.txtPaes.Name = "txtPaes";
            this.txtPaes.Size = new System.Drawing.Size(269, 38);
            this.txtPaes.TabIndex = 3;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(530, 64);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(131, 62);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(35)))), ((int)(((byte)(60)))));
            this.panel1.Controls.Add(this.lblQuest1);
            this.panel1.Location = new System.Drawing.Point(-8, -6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(820, 189);
            this.panel1.TabIndex = 5;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblQuest1
            // 
            this.lblQuest1.AutoSize = true;
            this.lblQuest1.Font = new System.Drawing.Font("Modern No. 20", 47.99999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest1.Location = new System.Drawing.Point(20, 60);
            this.lblQuest1.Name = "lblQuest1";
            this.lblQuest1.Size = new System.Drawing.Size(283, 65);
            this.lblQuest1.TabIndex = 5;
            this.lblQuest1.Text = "Questão 1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(114)))), ((int)(((byte)(239)))), ((int)(((byte)(221)))));
            this.panel2.Controls.Add(this.lblQtdBroas);
            this.panel2.Controls.Add(this.btnCalcular);
            this.panel2.Controls.Add(this.txtBroas);
            this.panel2.Controls.Add(this.txtPaes);
            this.panel2.Controls.Add(this.lblQtdPaes);
            this.panel2.Location = new System.Drawing.Point(-8, 168);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(820, 172);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(153)))), ((int)(((byte)(174)))));
            this.panel3.Controls.Add(this.lblResultado);
            this.panel3.Controls.Add(this.lblValoraPagar);
            this.panel3.Location = new System.Drawing.Point(-8, 335);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(810, 114);
            this.panel3.TabIndex = 5;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft YaHei UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(332, 34);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(55, 39);
            this.lblResultado.TabIndex = 1;
            this.lblResultado.Text = "R$";
            this.lblResultado.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblValoraPagar
            // 
            this.lblValoraPagar.AutoSize = true;
            this.lblValoraPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValoraPagar.Location = new System.Drawing.Point(20, 34);
            this.lblValoraPagar.Name = "lblValoraPagar";
            this.lblValoraPagar.Size = new System.Drawing.Size(306, 39);
            this.lblValoraPagar.TabIndex = 0;
            this.lblValoraPagar.Text = "VALOR A PAGAR:";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblQtdPaes;
        private System.Windows.Forms.Label lblQtdBroas;
        private System.Windows.Forms.TextBox txtBroas;
        private System.Windows.Forms.TextBox txtPaes;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblQuest1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblValoraPagar;
        private System.Windows.Forms.Label lblResultado;
    }
}

