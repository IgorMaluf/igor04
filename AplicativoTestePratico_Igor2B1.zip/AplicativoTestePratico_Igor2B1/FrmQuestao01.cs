﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicativoTestePratico_Igor2B1
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int QntPaes = int.Parse(txtPaes.Text);
            int QntBroas = int.Parse(txtBroas.Text);
            float total;
            total = QntBroas * 1.50f + QntPaes * 0.12f;
            lblResultado.Text = "R$" + total;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
