﻿namespace AplicativoTestePratico_Igor2B1
{
    partial class FrmQuestao03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlCiano = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlSalmao = new System.Windows.Forms.Panel();
            this.pnlMarinho = new System.Windows.Forms.Panel();
            this.lblLojaGames = new System.Windows.Forms.Label();
            this.lblProd2 = new System.Windows.Forms.Label();
            this.lblProd1 = new System.Windows.Forms.Label();
            this.lblProd3 = new System.Windows.Forms.Label();
            this.lblPreco1 = new System.Windows.Forms.Label();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtProd1 = new System.Windows.Forms.TextBox();
            this.txtProd2 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtProd3 = new System.Windows.Forms.TextBox();
            this.txtPreco1 = new System.Windows.Forms.TextBox();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblResultado1 = new System.Windows.Forms.Label();
            this.lblResultado3 = new System.Windows.Forms.Label();
            this.lblResultado2 = new System.Windows.Forms.Label();
            this.lblResultado4 = new System.Windows.Forms.Label();
            this.lblResultado5 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlCiano.SuspendLayout();
            this.pnlSalmao.SuspendLayout();
            this.pnlMarinho.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlCiano
            // 
            this.pnlCiano.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(201)))), ((int)(((byte)(240)))));
            this.pnlCiano.Controls.Add(this.lblLojaGames);
            this.pnlCiano.Controls.Add(this.flowLayoutPanel1);
            this.pnlCiano.Location = new System.Drawing.Point(0, 0);
            this.pnlCiano.Name = "pnlCiano";
            this.pnlCiano.Size = new System.Drawing.Size(801, 84);
            this.pnlCiano.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(193, 261);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(595, 177);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // pnlSalmao
            // 
            this.pnlSalmao.BackColor = System.Drawing.Color.Salmon;
            this.pnlSalmao.Controls.Add(this.txtPreco3);
            this.pnlSalmao.Controls.Add(this.txtPreco1);
            this.pnlSalmao.Controls.Add(this.txtProd3);
            this.pnlSalmao.Controls.Add(this.txtPreco2);
            this.pnlSalmao.Controls.Add(this.txtProd2);
            this.pnlSalmao.Controls.Add(this.txtProd1);
            this.pnlSalmao.Controls.Add(this.lblPreco3);
            this.pnlSalmao.Controls.Add(this.lblPreco2);
            this.pnlSalmao.Controls.Add(this.lblPreco1);
            this.pnlSalmao.Controls.Add(this.lblProd3);
            this.pnlSalmao.Controls.Add(this.lblProd2);
            this.pnlSalmao.Controls.Add(this.lblProd1);
            this.pnlSalmao.Location = new System.Drawing.Point(12, 90);
            this.pnlSalmao.Name = "pnlSalmao";
            this.pnlSalmao.Size = new System.Drawing.Size(381, 284);
            this.pnlSalmao.TabIndex = 2;
            // 
            // pnlMarinho
            // 
            this.pnlMarinho.BackColor = System.Drawing.Color.MidnightBlue;
            this.pnlMarinho.Controls.Add(this.lblResultado5);
            this.pnlMarinho.Controls.Add(this.lblResultado4);
            this.pnlMarinho.Controls.Add(this.lblResultado2);
            this.pnlMarinho.Controls.Add(this.lblResultado3);
            this.pnlMarinho.Controls.Add(this.lblResultado1);
            this.pnlMarinho.Controls.Add(this.lblParcela5);
            this.pnlMarinho.Controls.Add(this.lblParcela4);
            this.pnlMarinho.Controls.Add(this.lblParcela2);
            this.pnlMarinho.Controls.Add(this.lblParcela3);
            this.pnlMarinho.Controls.Add(this.lblParcela1);
            this.pnlMarinho.Location = new System.Drawing.Point(399, 90);
            this.pnlMarinho.Name = "pnlMarinho";
            this.pnlMarinho.Size = new System.Drawing.Size(389, 284);
            this.pnlMarinho.TabIndex = 3;
            // 
            // lblLojaGames
            // 
            this.lblLojaGames.AutoSize = true;
            this.lblLojaGames.Font = new System.Drawing.Font("Showcard Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLojaGames.Location = new System.Drawing.Point(32, 25);
            this.lblLojaGames.Name = "lblLojaGames";
            this.lblLojaGames.Size = new System.Drawing.Size(239, 36);
            this.lblLojaGames.TabIndex = 2;
            this.lblLojaGames.Text = "Loja de Games";
            // 
            // lblProd2
            // 
            this.lblProd2.AutoSize = true;
            this.lblProd2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd2.Location = new System.Drawing.Point(0, 102);
            this.lblProd2.Name = "lblProd2";
            this.lblProd2.Size = new System.Drawing.Size(131, 31);
            this.lblProd2.TabIndex = 3;
            this.lblProd2.Text = "Produto 2";
            // 
            // lblProd1
            // 
            this.lblProd1.AutoSize = true;
            this.lblProd1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd1.Location = new System.Drawing.Point(3, 16);
            this.lblProd1.Name = "lblProd1";
            this.lblProd1.Size = new System.Drawing.Size(131, 31);
            this.lblProd1.TabIndex = 4;
            this.lblProd1.Text = "Produto 1";
            // 
            // lblProd3
            // 
            this.lblProd3.AutoSize = true;
            this.lblProd3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProd3.Location = new System.Drawing.Point(0, 197);
            this.lblProd3.Name = "lblProd3";
            this.lblProd3.Size = new System.Drawing.Size(131, 31);
            this.lblProd3.TabIndex = 5;
            this.lblProd3.Text = "Produto 3";
            // 
            // lblPreco1
            // 
            this.lblPreco1.AutoSize = true;
            this.lblPreco1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco1.Location = new System.Drawing.Point(175, 16);
            this.lblPreco1.Name = "lblPreco1";
            this.lblPreco1.Size = new System.Drawing.Size(102, 31);
            this.lblPreco1.TabIndex = 6;
            this.lblPreco1.Text = "Preço 1";
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco2.Location = new System.Drawing.Point(175, 102);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(102, 31);
            this.lblPreco2.TabIndex = 7;
            this.lblPreco2.Text = "Preço 2";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco3.Location = new System.Drawing.Point(175, 197);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(102, 31);
            this.lblPreco3.TabIndex = 8;
            this.lblPreco3.Text = "Preço 3";
            // 
            // txtProd1
            // 
            this.txtProd1.Location = new System.Drawing.Point(9, 59);
            this.txtProd1.Name = "txtProd1";
            this.txtProd1.Size = new System.Drawing.Size(128, 20);
            this.txtProd1.TabIndex = 9;
            // 
            // txtProd2
            // 
            this.txtProd2.Location = new System.Drawing.Point(9, 140);
            this.txtProd2.Name = "txtProd2";
            this.txtProd2.Size = new System.Drawing.Size(128, 20);
            this.txtProd2.TabIndex = 10;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(181, 140);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(128, 20);
            this.txtPreco2.TabIndex = 11;
            // 
            // txtProd3
            // 
            this.txtProd3.Location = new System.Drawing.Point(9, 231);
            this.txtProd3.Name = "txtProd3";
            this.txtProd3.Size = new System.Drawing.Size(128, 20);
            this.txtProd3.TabIndex = 12;
            // 
            // txtPreco1
            // 
            this.txtPreco1.Location = new System.Drawing.Point(181, 59);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(128, 20);
            this.txtPreco1.TabIndex = 13;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(181, 231);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(128, 20);
            this.txtPreco3.TabIndex = 14;
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblParcela1.Location = new System.Drawing.Point(28, 21);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(181, 25);
            this.lblParcela1.TabIndex = 15;
            this.lblParcela1.Text = "01 Parcelas de :";
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblParcela3.Location = new System.Drawing.Point(28, 134);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(172, 25);
            this.lblParcela3.TabIndex = 16;
            this.lblParcela3.Text = "03 Parcela de :";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblParcela2.Location = new System.Drawing.Point(28, 77);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(172, 25);
            this.lblParcela2.TabIndex = 17;
            this.lblParcela2.Text = "02 Parcela de :";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblParcela4.Location = new System.Drawing.Point(28, 188);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(172, 25);
            this.lblParcela4.TabIndex = 18;
            this.lblParcela4.Text = "04 Parcela de :";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblParcela5.Location = new System.Drawing.Point(28, 243);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(180, 25);
            this.lblParcela5.TabIndex = 19;
            this.lblParcela5.Text = "05 Parcela de : ";
            // 
            // lblResultado1
            // 
            this.lblResultado1.AutoSize = true;
            this.lblResultado1.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado1.Location = new System.Drawing.Point(249, 21);
            this.lblResultado1.Name = "lblResultado1";
            this.lblResultado1.Size = new System.Drawing.Size(0, 28);
            this.lblResultado1.TabIndex = 20;
            // 
            // lblResultado3
            // 
            this.lblResultado3.AutoSize = true;
            this.lblResultado3.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado3.Location = new System.Drawing.Point(249, 131);
            this.lblResultado3.Name = "lblResultado3";
            this.lblResultado3.Size = new System.Drawing.Size(0, 28);
            this.lblResultado3.TabIndex = 21;
            // 
            // lblResultado2
            // 
            this.lblResultado2.AutoSize = true;
            this.lblResultado2.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado2.Location = new System.Drawing.Point(249, 74);
            this.lblResultado2.Name = "lblResultado2";
            this.lblResultado2.Size = new System.Drawing.Size(0, 28);
            this.lblResultado2.TabIndex = 22;
            // 
            // lblResultado4
            // 
            this.lblResultado4.AutoSize = true;
            this.lblResultado4.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado4.Location = new System.Drawing.Point(249, 188);
            this.lblResultado4.Name = "lblResultado4";
            this.lblResultado4.Size = new System.Drawing.Size(0, 28);
            this.lblResultado4.TabIndex = 23;
            // 
            // lblResultado5
            // 
            this.lblResultado5.AutoSize = true;
            this.lblResultado5.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblResultado5.Location = new System.Drawing.Point(249, 240);
            this.lblResultado5.Name = "lblResultado5";
            this.lblResultado5.Size = new System.Drawing.Size(0, 28);
            this.lblResultado5.TabIndex = 24;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Stencil", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(12, 380);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(776, 58);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmQuestao03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(55)))), ((int)(((byte)(201)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlMarinho);
            this.Controls.Add(this.pnlSalmao);
            this.Controls.Add(this.pnlCiano);
            this.Name = "FrmQuestao03";
            this.Text = "FrmQuestao03";
            this.pnlCiano.ResumeLayout(false);
            this.pnlCiano.PerformLayout();
            this.pnlSalmao.ResumeLayout(false);
            this.pnlSalmao.PerformLayout();
            this.pnlMarinho.ResumeLayout(false);
            this.pnlMarinho.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlCiano;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lblLojaGames;
        private System.Windows.Forms.Panel pnlSalmao;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco1;
        private System.Windows.Forms.TextBox txtProd3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtProd2;
        private System.Windows.Forms.TextBox txtProd1;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label lblPreco1;
        private System.Windows.Forms.Label lblProd3;
        private System.Windows.Forms.Label lblProd2;
        private System.Windows.Forms.Label lblProd1;
        private System.Windows.Forms.Panel pnlMarinho;
        private System.Windows.Forms.Label lblResultado5;
        private System.Windows.Forms.Label lblResultado4;
        private System.Windows.Forms.Label lblResultado2;
        private System.Windows.Forms.Label lblResultado3;
        private System.Windows.Forms.Label lblResultado1;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Button btnCalcular;
    }
}